var FeedParser = require('feedparser')
  , fs = require('fs')
  , feed ='https://timesofindia.indiatimes.com/rssfeedstopstories.cms';
var request = require('request');
var req = request(feed);
var feedparser = new FeedParser();

var csvWriter = require('csv-write-stream')

var writer = csvWriter({sendHeaders: false})


req.on('error', function (error) {
  // handle any request errors
});

req.on('response', function (res) {
  var stream = this; // `this` is `req`, which is a stream

  if (res.statusCode !== 200) {
    this.emit('error', new Error('Bad status code'));
  }  else {
    writer.pipe(fs.createWriteStream('feed.csv', {flags: 'a'}))
    stream.pipe(feedparser);
  }
});

feedparser.on('error', function (error) {
  // always handle errors
});

feedparser.on('readable', function () {
  // This is where the action is!
  var stream = this; // `this` is `feedparser`, which is a stream
  var meta = this.meta; // **NOTE** the "meta" is always available in the context of the feedparser instance
  var item;
  var items = [];
  while (item = stream.read()) {
    var tmp = {'link' : item.link, 'pubdate' : item.pubdate, 'date' : item.date, 'title' : item.title, 'summary' : item.summary}
    //items.push({'link' : item.link, 'pubdate' : item.pubdate, 'date' : item.date, 'title' : item.title, 'summary' : item.summary});
    console.log(tmp);
    
    writer.write(tmp)
    
    
  }
  
});

feedparser.on('end', function(){
  writer.end();
})